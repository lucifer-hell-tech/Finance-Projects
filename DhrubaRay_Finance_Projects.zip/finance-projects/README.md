# 📊 Finance Projects by Dhruba Ray

Welcome to my finance projects portfolio — a collection of academic and applied work in financial modeling, investment analysis, and risk management. These projects demonstrate my ability to work with real-world data, apply financial theories, and generate actionable insights using tools like Python, R, and Excel.

---

## 🔹 Equity Research Report: Volvo Group (BUY, +55% Upside)
**📁 Folder:** `/equity-research-volvo/`  
A professional-grade equity research report recommending a BUY on Volvo Group with a target price of SEK 443 (55% upside).  
📌 **Tools:** DCF valuation (WACC 7.3%), industry benchmarking, strategic analysis (EV, autonomous tech).

---

## 🔹 Portfolio Optimization & Efficient Frontier Analysis
**📁 Folder:** `/portfolio-optimization/`  
Constructed Minimum Variance and Tangency Portfolios using historical stock data. Compared returns and volatility with NIFTY 50 and visualized the efficient frontier.  
📌 **Tools:** Python (NumPy, pandas, matplotlib), Markowitz Model, CAPM, Sharpe Ratio.

---

## 🔹 Financial Risk Modeling & Volatility Forecasting
**📁 Folder:** `/financial-risk-modeling/`  
Performed risk modeling on Indian stocks using CAPM, ARIMA, GARCH, EGARCH, and VaR techniques. Analysis spans daily, weekly, and monthly returns.  
📌 **Tools:** Python, R, Time-Series Analysis, Ljung-Box, AIC/BIC diagnostics.

---

## 📫 Contact

📧 dhrubaray2003@gmail.com  
🔗 [LinkedIn](https://www.linkedin.com/in/dhruba-ray-166b80227/)  
